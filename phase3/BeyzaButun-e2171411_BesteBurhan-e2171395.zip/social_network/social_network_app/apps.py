from django.apps import AppConfig


class SocialNetworkAppConfig(AppConfig):
    name = 'social_network_app'
